#!/usr/bin/env bash
#
# check_axioms_inline.sh - Check axioms in Lean 4 files using inline #print axioms
#
# Usage:
#   ./check_axioms_inline.sh <file-or-dir-or-pattern> [--verbose] [--exit-zero-on-findings]
#   ./check_axioms_inline.sh src/**/*.lean
#   ./check_axioms_inline.sh src/              # recursively finds .lean files
#   ./check_axioms_inline.sh MyFile.lean --verbose --report-only
#
# This script temporarily appends #print axioms commands to Lean files,
# runs Lean to check axioms, then removes the additions.
#
# Limitations:
#   - Only detects the first namespace in a file
#   - Only captures top-level (unindented) declarations
#   - Nested namespaces, sections, and indented declarations may be missed
#
# Standard mathlib axioms (propext, quot.sound, choice) are filtered out,
# highlighting only custom axioms or unexpected dependencies.
#
# Examples:
#   ./check_axioms_inline.sh MyFile.lean
#   ./check_axioms_inline.sh src/**/*.lean
#   ./check_axioms_inline.sh "Exchangeability/**/*.lean" --verbose
#
# IMPORTANT: This script temporarily modifies files. Make sure:
#   - Files are in version control (can revert if needed)
#   - No other processes are editing the files

set -euo pipefail

# Track backup files for cleanup on interrupt using marker files
# Marker files are more robust than arrays for SIGINT handling
MARKER_DIR=$(mktemp -d)
cleanup() {
    # Find all marker files and restore corresponding backups
    # Use nullglob to handle case when no markers exist
    local marker
    for marker in "$MARKER_DIR"/*.marker; do
        [[ -f "$marker" ]] || continue
        local original
        original=$(cat "$marker")
        if [[ -f "$original.axiom_check_backup" ]]; then
            mv "$original.axiom_check_backup" "$original"
        fi
        rm -f "$marker"
    done
    rm -rf "$MARKER_DIR"
}
trap cleanup EXIT INT TERM

# Configuration
VERBOSE=""
EXIT_ZERO_ON_FINDINGS=""
FILES=()
MARKER="-- AUTO_AXIOM_CHECK_MARKER_DO_NOT_COMMIT"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Standard acceptable axioms (+ project negation axiom for extended mode)
STANDARD_AXIOMS="propext|quot.sound|Classical.choice|Quot.sound|Lean.ofReduceBool|Lean.trustCompiler|negation"

# Parse arguments
FILE_COUNTER=0
for arg in "$@"; do
    case "$arg" in
        --verbose)
            VERBOSE="--verbose"
            ;;
        --exit-zero-on-findings|--report-only)
            EXIT_ZERO_ON_FINDINGS="true"
            ;;
        --*)
            echo -e "${RED}Error: Unknown flag: $arg${NC}" >&2
            exit 1
            ;;
        *)
            # Expand globs
            if [[ "$arg" == *"*"* ]]; then
                # shellcheck disable=SC2206
                expanded=($arg)
                for file in "${expanded[@]}"; do
                    [[ -f "$file" ]] && FILES+=("$file")
                done
            elif [[ -d "$arg" ]]; then
                # Directory support: recursively find .lean files
                while IFS= read -r -d '' file; do
                    FILES+=("$file")
                done < <(find "$arg" -name '*.lean' -type f -print0)
            elif [[ -f "$arg" ]]; then
                FILES+=("$arg")
            else
                echo -e "${RED}Error: $arg is not a file or directory${NC}" >&2
                exit 1
            fi
            ;;
    esac
done

# Deduplicate files by realpath
declare -A SEEN_PATHS
DEDUPED_FILES=()
for file in "${FILES[@]}"; do
    local_real=$(realpath "$file" 2>/dev/null || echo "$file")
    if [[ -z "${SEEN_PATHS[$local_real]+x}" ]]; then
        SEEN_PATHS[$local_real]=1
        DEDUPED_FILES+=("$file")
    fi
done
FILES=("${DEDUPED_FILES[@]}")

# Validate input
if [[ ${#FILES[@]} -eq 0 ]]; then
    echo -e "${RED}Error: No files specified${NC}" >&2
    echo "Usage: $0 <file-or-pattern> [--verbose] [--exit-zero-on-findings]" >&2
    echo "Examples:" >&2
    echo "  $0 MyFile.lean" >&2
    echo "  $0 src/**/*.lean" >&2
    echo "  $0 \"Exchangeability/**/*.lean\" --verbose" >&2
    exit 1
fi

# Filter to .lean files only
LEAN_FILES=()
for file in "${FILES[@]}"; do
    if [[ "$file" =~ \.lean$ ]]; then
        LEAN_FILES+=("$file")
    fi
done

if [[ ${#LEAN_FILES[@]} -eq 0 ]]; then
    echo -e "${RED}Error: No Lean files found${NC}" >&2
    exit 1
fi

# Summary
if [[ ${#LEAN_FILES[@]} -eq 1 ]]; then
    echo -e "${BLUE}Checking axioms in 1 file${NC}"
else
    echo -e "${BLUE}Checking axioms in ${#LEAN_FILES[@]} files${NC}"
fi
echo

# Global counters
TOTAL_FILES=0
TOTAL_DECLARATIONS=0
FILES_WITH_CUSTOM=0
CUSTOM_AXIOM_COUNT=0

# Check single file
check_file() {
    local FILE="$1"

    echo -e "${BLUE}File: ${YELLOW}$FILE${NC}"

    # Extract namespace if any
    local NAMESPACE=""
    if grep -q "^namespace " "$FILE"; then
        NAMESPACE=$(grep "^namespace " "$FILE" | head -1 | sed 's/namespace //')
    fi

    # Extract all theorem/lemma/def declarations (including structure, class, inductive)
    local DECLARATIONS=()
    while IFS= read -r line; do
        decl=$(echo "$line" | sed -E 's/^(theorem|lemma|def|instance|abbrev|example|structure|class|inductive) +([^ :(]+).*/\2/')
        # Skip if sed didn't extract a name (decl == original line) or name is ":"
        if [[ -n "$decl" && "$decl" != "$line" && "$decl" != ":" ]]; then
            # Add namespace prefix if present
            if [[ -n "$NAMESPACE" ]]; then
                DECLARATIONS+=("$NAMESPACE.$decl")
            else
                DECLARATIONS+=("$decl")
            fi
        fi
    # Note: We match only declarations that START at column 0 with the keyword directly
    # Lines starting with 'private ', 'protected ', or 'local ' won't match
    # This is intentional - those declarations are not accessible outside their scope
    done < <(grep -E '^(theorem|lemma|def|instance|abbrev|example|structure|class|inductive) ' "$FILE" 2>/dev/null || true)

    if [[ ${#DECLARATIONS[@]} -eq 0 ]]; then
        echo -e "  ${YELLOW}No declarations found${NC}"
        echo
        return 0
    fi

    echo -e "  ${GREEN}Found ${#DECLARATIONS[@]} declarations${NC}"

    # Create backup and track it with marker file for SIGINT safety
    local BACKUP_FILE="${FILE}.axiom_check_backup"
    ((FILE_COUNTER++)) || true
    local MARKER_FILE="$MARKER_DIR/${FILE_COUNTER}_$(basename "$FILE").marker"
    cp "$FILE" "$BACKUP_FILE"
    echo "$FILE" > "$MARKER_FILE"

    # Function to restore file and remove marker
    local cleanup_done=false
    cleanup_file() {
        if [[ "$cleanup_done" == false && -f "$BACKUP_FILE" ]]; then
            mv "$BACKUP_FILE" "$FILE"
            cleanup_done=true
            rm -f "$MARKER_FILE"
        fi
    }

    # Append #print axioms commands
    echo "" >> "$FILE"
    echo "$MARKER" >> "$FILE"
    for decl in "${DECLARATIONS[@]}"; do
        echo "#print axioms $decl" >> "$FILE"
    done

    # Run Lean
    local HAS_CUSTOM=false
    if OUTPUT=$(timeout 1800 lake env lean "$FILE" 2>&1); then
        # Parse output - only match '#print axioms' output lines
        # Format: 'DeclName' depends on axioms: [ax1, ax2, ...]
        # Format: 'DeclName' does not depend on any axioms

        while IFS= read -r line; do
            # Match: 'Foo' depends on axioms: [ax1, ax2, ...]
            if [[ "$line" =~ \'([^\']+)\'[[:space:]]+depends[[:space:]]+on[[:space:]]+axioms:[[:space:]]*\[([^]]*)\] ]]; then
                local CURRENT_DECL="${BASH_REMATCH[1]}"
                local axiom_list="${BASH_REMATCH[2]}"
                if [[ "$VERBOSE" == "--verbose" ]]; then
                    echo -e "  ${BLUE}$CURRENT_DECL:${NC}"
                fi
                # Split comma-separated axiom list
                IFS=',' read -ra axioms <<< "$axiom_list"
                for axiom_raw in "${axioms[@]}"; do
                    # Trim whitespace
                    axiom=$(echo "$axiom_raw" | xargs)
                    if [[ -n "$axiom" ]]; then
                        if [[ ! "$axiom" =~ $STANDARD_AXIOMS ]]; then
                            echo -e "  ${RED}⚠ $CURRENT_DECL uses non-standard axiom: $axiom${NC}"
                            HAS_CUSTOM=true
                            ((CUSTOM_AXIOM_COUNT++))
                        elif [[ "$VERBOSE" == "--verbose" ]]; then
                            echo -e "    ${GREEN}✓${NC} $axiom (standard)"
                        fi
                    fi
                done
            elif [[ "$line" =~ \'([^\']+)\'[[:space:]]+does[[:space:]]+not[[:space:]]+depend ]]; then
                if [[ "$VERBOSE" == "--verbose" ]]; then
                    echo -e "  ${BLUE}${BASH_REMATCH[1]}: ${GREEN}no axioms${NC}"
                fi
            fi
        done <<< "$OUTPUT"

        if [[ "$HAS_CUSTOM" == false ]]; then
            echo -e "  ${GREEN}✓ All declarations use only standard axioms${NC}"
        else
            ((FILES_WITH_CUSTOM++))
        fi

        ((TOTAL_DECLARATIONS+=${#DECLARATIONS[@]}))
        ((TOTAL_FILES++))

        cleanup_file
        echo
        return 0
    else
        # Check if errors are ONLY unknownIdentifier in our appended #print axioms region
        # Real errors in the original file should still fail

        # Find line number where our marker starts (original file length + 1)
        local MARKER_LINE
        MARKER_LINE=$(grep -nF -- "$MARKER" "$FILE" | head -1 | cut -d: -f1)

        # Extract all error line numbers from output (format: file.lean:LINE:COL: error)
        local HAS_REAL_ERROR=false
        while IFS= read -r error_line; do
            if [[ "$error_line" =~ :([0-9]+):[0-9]+:.*error ]]; then
                local err_lineno="${BASH_REMATCH[1]}"
                # If error is before our appended region, it's a real error
                if [[ -n "$MARKER_LINE" && "$err_lineno" -lt "$MARKER_LINE" ]]; then
                    HAS_REAL_ERROR=true
                    break
                fi
            fi
        done < <(echo "$OUTPUT" | grep -E ':[0-9]+:[0-9]+:.*error')

        # Also check: if there are errors that aren't unknownIdentifier types, fail
        if echo "$OUTPUT" | grep -E ':[0-9]+:[0-9]+:.*error' | grep -qvE 'unknownIdentifier|unknown identifier|unknown constant'; then
            HAS_REAL_ERROR=true
        fi

        if [[ "$HAS_REAL_ERROR" == false ]] && echo "$OUTPUT" | grep -q 'unknownIdentifier\|unknown identifier\|unknown constant'; then
            # Only unknownIdentifier errors in the appended region - treat as warning
            echo -e "  ${YELLOW}⚠ Some declarations not accessible (private/local)${NC}"

            # Still try to parse any successful #print axioms results from output
            local PARSED_ANY=false

            while IFS= read -r line; do
                # Match: 'Foo' depends on axioms: [ax1, ax2, ...]
                if [[ "$line" =~ \'([^\']+)\'[[:space:]]+depends[[:space:]]+on[[:space:]]+axioms:[[:space:]]*\[([^]]*)\] ]]; then
                    local CURRENT_DECL="${BASH_REMATCH[1]}"
                    local axiom_list="${BASH_REMATCH[2]}"
                    PARSED_ANY=true
                    if [[ "$VERBOSE" == "--verbose" ]]; then
                        echo -e "  ${BLUE}$CURRENT_DECL:${NC}"
                    fi
                    # Split comma-separated axiom list
                    IFS=',' read -ra axioms <<< "$axiom_list"
                    for axiom_raw in "${axioms[@]}"; do
                        axiom=$(echo "$axiom_raw" | xargs)
                        if [[ -n "$axiom" ]]; then
                            if [[ ! "$axiom" =~ $STANDARD_AXIOMS ]]; then
                                echo -e "  ${RED}⚠ $CURRENT_DECL uses non-standard axiom: $axiom${NC}"
                                HAS_CUSTOM=true
                                ((CUSTOM_AXIOM_COUNT++))
                            elif [[ "$VERBOSE" == "--verbose" ]]; then
                                echo -e "    ${GREEN}✓${NC} $axiom (standard)"
                            fi
                        fi
                    done
                elif [[ "$line" =~ \'([^\']+)\'[[:space:]]+does[[:space:]]+not[[:space:]]+depend ]]; then
                    PARSED_ANY=true
                    if [[ "$VERBOSE" == "--verbose" ]]; then
                        echo -e "  ${BLUE}${BASH_REMATCH[1]}: ${GREEN}no axioms${NC}"
                    fi
                fi
            done <<< "$OUTPUT"

            if [[ "$PARSED_ANY" == true ]]; then
                if [[ "$HAS_CUSTOM" == false ]]; then
                    echo -e "  ${GREEN}✓ Accessible declarations use only standard axioms${NC}"
                else
                    ((FILES_WITH_CUSTOM++))
                fi
                ((TOTAL_DECLARATIONS+=${#DECLARATIONS[@]}))
                ((TOTAL_FILES++))
            fi

            cleanup_file
            echo
            return 0  # Don't fail - just warn about inaccessible declarations
        else
            # Real error - not just unknownIdentifier in appended region
            echo -e "  ${RED}Error running Lean${NC}" >&2
            echo "$OUTPUT" | grep "error" | head -10 | sed 's/^/  /' >&2
            cleanup_file
            echo
            return 1
        fi
    fi
}

# Check all files
FAILED_FILES=()
for file in "${LEAN_FILES[@]}"; do
    if ! check_file "$file"; then
        FAILED_FILES+=("$file")
    fi
done

# Summary
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Summary:${NC}"
echo -e "  Files checked: $TOTAL_FILES"
echo -e "  Declarations checked: $TOTAL_DECLARATIONS"

if [[ $FILES_WITH_CUSTOM -eq 0 ]]; then
    echo -e "  ${GREEN}✓ All files use only standard axioms${NC}"
else
    echo -e "  ${RED}⚠ Files with non-standard axioms: $FILES_WITH_CUSTOM${NC}"
    echo -e "  ${RED}⚠ Total non-standard axiom usages: $CUSTOM_AXIOM_COUNT${NC}"
fi

if [[ ${#FAILED_FILES[@]} -gt 0 ]]; then
    echo -e "  ${RED}✗ Files with errors: ${#FAILED_FILES[@]}${NC}"
    for file in "${FAILED_FILES[@]}"; do
        echo -e "    - $file"
    done
fi

echo
echo -e "${YELLOW}Standard axioms (acceptable):${NC}"
echo "  • propext (propositional extensionality)"
echo "  • quot.sound (quotient soundness)"
echo "  • Classical.choice (axiom of choice)"
echo "  • Lean.ofReduceBool (native_decide kernel reduction)"
echo "  • Lean.trustCompiler (native_decide compiler trust)"

if [[ $FILES_WITH_CUSTOM -gt 0 ]]; then
    echo
    echo -e "${YELLOW}Tip: Non-standard axioms should have elimination plans${NC}"
    [[ -z "$EXIT_ZERO_ON_FINDINGS" ]] && exit 1
fi

if [[ ${#FAILED_FILES[@]} -gt 0 ]]; then
    exit 1
fi

exit 0
