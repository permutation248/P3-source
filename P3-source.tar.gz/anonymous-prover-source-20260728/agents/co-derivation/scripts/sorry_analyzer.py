#!/usr/bin/env python3
"""
sorry_analyzer.py - Extract and analyze sorry statements in Lean 4 code

Usage:
    ./sorry_analyzer.py <file-or-directory> [--format=FORMAT | --format FORMAT] [--interactive] [--include-deps] [--exit-zero-on-findings]

This script finds all 'sorry' instances in Lean files and extracts:
- Location (file, line number)
- Context (surrounding code)
- Documentation (TODO comments)
- Type information (from goal state if available)

Modes:
    --interactive: Interactive mode to pick which sorry to work on
    --format=FORMAT (or --format FORMAT): Output format (text, json, markdown, summary)
    --include-deps: Include .lake/ directories (dependencies) in search (excluded by default)
    --exit-zero-on-findings (or --report-only): Exit 0 even when sorries are found (real errors still exit 1)

Examples:
    ./sorry_analyzer.py MyFile.lean
    ./sorry_analyzer.py src/DeFinetti/ --format=markdown
    ./sorry_analyzer.py . --format=json > sorries.json
    ./sorry_analyzer.py . --format=summary
    ./sorry_analyzer.py . --interactive
    ./sorry_analyzer.py . --format json              # space-separated format flag
    ./sorry_analyzer.py . --format=detail            # alias for text
"""

import re
import sys
import json
import subprocess
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple

@dataclass
class Sorry:
    """Represents a sorry instance with context"""
    file: str
    line: int
    context_before: List[str]
    context_after: List[str]
    documentation: List[str]
    in_declaration: Optional[str] = None
    kind: Optional[str] = None  # "code" or "proof"

SORRY_TOKEN_PATTERN = re.compile(r"(?<![A-Za-z0-9_!?'])sorry(?![A-Za-z0-9_!?'])")

def classify_sorry(lines: List[str], sorry_idx: int, declaration: Optional[str]) -> str:
    """Classify a sorry as 'code' or 'proof'.

    - 'proof': sorry inside a `by` tactic block after theorem/lemma/example := by
    - 'code': everything else (def body, decreasing_by, termination_by, etc.)

    Heuristic: scan backwards from the sorry line. Track whether we're inside
    a `by` block that belongs to a theorem/lemma (proof) or a def (code).
    `decreasing_by` / `termination_by` sorry is always code.
    """
    # Check if this sorry is inside a decreasing_by or termination_by block
    for i in range(sorry_idx, max(-1, sorry_idx - 5), -1):
        stripped = lines[i].strip()
        if re.match(r'^(decreasing_by|termination_by)\b', stripped):
            return "code"

    if declaration is None:
        return "code"

    decl_kind = declaration.split()[0] if declaration else ""

    # theorem/lemma/example -> proof sorry
    if decl_kind in ("theorem", "lemma", "example"):
        return "proof"

    # def/instance/structure/class -> code sorry
    return "code"

def strip_lean_comments_and_strings(line: str, block_comment_depth: int) -> Tuple[str, int]:
    """Return code-only text for a line and updated Lean block-comment depth.

    Handles:
    - line comments: -- ...
    - nested block comments: /- ... -/
    - string literals: "..."
    """
    result: List[str] = []
    i = 0
    n = len(line)
    in_string = False

    while i < n:
        ch = line[i]
        nxt = line[i + 1] if i + 1 < n else ''

        if block_comment_depth > 0:
            if ch == '/' and nxt == '-':
                block_comment_depth += 1
                i += 2
                continue
            if ch == '-' and nxt == '/':
                block_comment_depth -= 1
                i += 2
                continue
            i += 1
            continue

        if in_string:
            if ch == '\\' and i + 1 < n:
                i += 2
                continue
            if ch == '"':
                in_string = False
            i += 1
            continue

        if ch == '"' and block_comment_depth == 0:
            in_string = True
            i += 1
            continue

        if ch == '-' and nxt == '-':
            break

        if ch == '/' and nxt == '-':
            block_comment_depth += 1
            i += 2
            continue

        result.append(ch)
        i += 1

    return ''.join(result), block_comment_depth

def extract_declaration_name(lines: List[str], sorry_idx: int) -> Optional[str]:
    """Extract the theorem/lemma/def name containing this sorry"""
    # Search backwards for declaration
    # Support Unicode and qualified names (e.g., Foo.bar, foo', foo'')
    # Handle optional visibility modifiers (private, protected) and attributes (@[...])
    for i in range(sorry_idx, max(0, sorry_idx - 50), -1):
        match = re.match(
            r"^\s*(?:@\[.*?\]\s*)?(?:private\s+|protected\s+)?"
            r"(theorem|lemma|def|example|instance|structure|class)\s+([\w.']+)",
            lines[i]
        )
        if match:
            return f"{match.group(1)} {match.group(2)}"
    return None

def extract_documentation(lines: List[str], sorry_idx: int) -> List[str]:
    """Extract TODO/NOTE comments near the sorry"""
    docs = []
    keywords = ['TODO', 'NOTE', 'FIXME', 'STRATEGY', 'DEPENDENCIES']

    # Check lines BEFORE sorry (often comments precede the sorry)
    for i in range(max(0, sorry_idx - 5), sorry_idx):
        line = lines[i].strip()
        if line.startswith('--'):
            comment = line[2:].strip()
            if any(keyword in comment.upper() for keyword in keywords):
                docs.append(comment)

    # Check lines AFTER sorry
    for i in range(sorry_idx + 1, min(len(lines), sorry_idx + 10)):
        line = lines[i].strip()
        if line.startswith('--'):
            comment = line[2:].strip()
            if any(keyword in comment.upper() for keyword in keywords):
                docs.append(comment)
        elif line and not line.startswith('--'):
            break
    return docs

def find_sorries_in_file(filepath: Path) -> List[Sorry]:
    """Find all sorries in a single Lean file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Warning: Could not read {filepath}: {e}", file=sys.stderr)
        return []

    sorries = []
    block_comment_depth = 0
    for i, line in enumerate(lines):
        # Fast path when we're not inside a block comment and the line has no
        # token of interest for sorry/comment/string parsing.
        if block_comment_depth == 0 and 'sorry' not in line and '/-' not in line and '"' not in line:
            continue

        code_part, block_comment_depth = strip_lean_comments_and_strings(line, block_comment_depth)
        if 'sorry' not in code_part:
            continue

        if SORRY_TOKEN_PATTERN.search(code_part):
            context_before = [l.rstrip() for l in lines[max(0, i-3):i]]
            context_after = [l.rstrip() for l in lines[i+1:min(len(lines), i+4)]]

            decl = extract_declaration_name(lines, i)
            sorry = Sorry(
                file=str(filepath),
                line=i + 1,  # 1-indexed
                context_before=context_before,
                context_after=context_after,
                documentation=extract_documentation(lines, i),
                in_declaration=decl,
                kind=classify_sorry(lines, i, decl)
            )
            sorries.append(sorry)

    return sorries

def find_sorries(target: Path, include_deps: bool = False) -> List[Sorry]:
    """Find all sorries in target file or directory

    Args:
        target: File or directory to search
        include_deps: If False (default), exclude .lake/ directories (dependencies)
    """
    if target.is_file():
        # Guard: Also exclude .lake/ files unless --include-deps
        if not include_deps and '.lake' in target.parts:
            print(f"Skipping dependency file: {target} (use --include-deps to include)", file=sys.stderr)
            return []
        return find_sorries_in_file(target)
    elif target.is_dir():
        # Guard: Exclude .lake directory or any subpath unless --include-deps
        if not include_deps and '.lake' in target.parts:
            print(f"Skipping dependency directory: {target} (use --include-deps to include)", file=sys.stderr)
            return []
        sorries = []
        # Use os.walk for early termination of .lake/ directories (performance)
        import os
        for root, dirs, files in os.walk(target):
            # Prune .lake directories from traversal (don't descend into them)
            if not include_deps:
                dirs[:] = [d for d in dirs if d != '.lake']
            for filename in files:
                if filename.endswith('.lean'):
                    lean_file = Path(root) / filename
                    sorries.extend(find_sorries_in_file(lean_file))
        return sorries
    else:
        raise ValueError(f"{target} is not a file or directory")

def format_text(sorries: List[Sorry]) -> str:
    """Format sorries as human-readable text"""
    output = []
    output.append(f"Found {len(sorries)} sorry statement(s)\n")
    output.append("=" * 80)

    for i, sorry in enumerate(sorries, 1):
        kind_tag = f" [{sorry.kind}]" if sorry.kind else ""
        output.append(f"\n[{i}] {sorry.file}:{sorry.line}{kind_tag}")
        if sorry.in_declaration:
            output.append(f"    In: {sorry.in_declaration}")

        if sorry.documentation:
            output.append("    Documentation:")
            for doc in sorry.documentation:
                output.append(f"      • {doc}")

        output.append("\n    Context:")
        for line in sorry.context_before[-2:]:
            output.append(f"      {line}")
        output.append(f"      >>> SORRY <<<")
        for line in sorry.context_after[:2]:
            output.append(f"      {line}")
        output.append("")

    return "\n".join(output)

def format_markdown(sorries: List[Sorry]) -> str:
    """Format sorries as Markdown"""
    output = []
    output.append(f"# Sorry Analysis Report\n")
    output.append(f"**Total sorries found:** {len(sorries)}\n")

    # Group by file
    by_file = {}
    for sorry in sorries:
        by_file.setdefault(sorry.file, []).append(sorry)

    for filepath, file_sorries in sorted(by_file.items()):
        output.append(f"## {filepath}\n")
        output.append(f"**Count:** {len(file_sorries)}\n")

        for sorry in file_sorries:
            output.append(f"### Line {sorry.line}")
            if sorry.in_declaration:
                output.append(f"**Declaration:** `{sorry.in_declaration}`\n")

            if sorry.documentation:
                output.append("**Documentation:**")
                for doc in sorry.documentation:
                    output.append(f"- {doc}")
                output.append("")

            output.append("**Context:**")
            output.append("```lean")
            for line in sorry.context_before[-2:]:
                output.append(line)
            output.append("sorry  -- ⚠️")
            for line in sorry.context_after[:2]:
                output.append(line)
            output.append("```\n")

    return "\n".join(output)

def format_json(sorries: List[Sorry]) -> str:
    """Format sorries as JSON"""
    return json.dumps({
        'total_count': len(sorries),
        'sorries': [asdict(s) for s in sorries]
    }, indent=2)

def format_summary(sorries: List[Sorry]) -> str:
    """Format sorries as a brief summary (file counts + total)"""
    output = []
    # Group by file
    by_file = {}
    for sorry in sorries:
        by_file.setdefault(sorry.file, []).append(sorry)

    code_count = sum(1 for s in sorries if s.kind == "code")
    proof_count = sum(1 for s in sorries if s.kind == "proof")
    output.append(f"Sorry Summary: {len(sorries)} total ({code_count} code, {proof_count} proof) across {len(by_file)} file(s)")
    output.append("-" * 50)

    for filepath, file_sorries in sorted(by_file.items(), key=lambda x: -len(x[1])):
        fc = sum(1 for s in file_sorries if s.kind == "code")
        fp = sum(1 for s in file_sorries if s.kind == "proof")
        output.append(f"  {filepath}: {len(file_sorries)} sorries ({fc} code, {fp} proof)")

    return "\n".join(output)

def interactive_mode(sorries: List[Sorry]):
    """Interactive mode to navigate and select sorries"""
    if not sorries:
        print("No sorries found!")
        return

    # Group by file
    by_file = {}
    for sorry in sorries:
        by_file.setdefault(sorry.file, []).append(sorry)

    print(f"\n{'='*80}")
    print(f"Found {len(sorries)} sorry statement(s) across {len(by_file)} file(s)")
    print(f"{'='*80}\n")

    # Display files with sorry counts
    files = sorted(by_file.items(), key=lambda x: len(x[1]), reverse=True)
    print("Files with sorries:")
    for i, (filepath, file_sorries) in enumerate(files, 1):
        print(f"  [{i}] {filepath} ({len(file_sorries)} sorries)")

    print("\nOptions:")
    print("  [1-N] - View sorries in file N")
    print("  [q]   - Quit")

    while True:
        try:
            choice = input("\nSelect file (or 'q' to quit): ").strip()
            if choice.lower() == 'q':
                break

            idx = int(choice) - 1
            if 0 <= idx < len(files):
                filepath, file_sorries = files[idx]
                show_file_sorries(filepath, file_sorries)
            else:
                print("Invalid selection")
        except (ValueError, EOFError, KeyboardInterrupt):
            print("\nExiting...")
            break

def show_file_sorries(filepath: str, sorries: List[Sorry]):
    """Show sorries in a specific file with navigation"""
    print(f"\n{'='*80}")
    print(f"File: {filepath}")
    print(f"{'='*80}\n")

    for i, sorry in enumerate(sorries, 1):
        print(f"[{i}] Line {sorry.line}", end="")
        if sorry.in_declaration:
            print(f" - {sorry.in_declaration}", end="")
        print()

    print("\nOptions:")
    print("  [1-N]  - View sorry details")
    print("  [o N]  - Open file at sorry N in $EDITOR")
    print("  [b]    - Back to file list")
    print("  [q]    - Quit")

    while True:
        try:
            choice = input("\nSelect sorry (or 'b'/'q'): ").strip()

            if choice.lower() == 'q':
                sys.exit(0)
            elif choice.lower() == 'b':
                return
            elif choice.lower().startswith('o '):
                # Open in editor
                try:
                    idx = int(choice.split()[1]) - 1
                    if 0 <= idx < len(sorries):
                        sorry = sorries[idx]
                        editor = subprocess.os.environ.get('EDITOR', 'vim')
                        subprocess.call([editor, f"+{sorry.line}", sorry.file])
                    else:
                        print("Invalid selection")
                except (ValueError, IndexError):
                    print("Usage: o <number>")
            else:
                idx = int(choice) - 1
                if 0 <= idx < len(sorries):
                    show_sorry_details(sorries[idx])
                else:
                    print("Invalid selection")
        except (ValueError, EOFError, KeyboardInterrupt):
            print("\nExiting...")
            sys.exit(0)

def show_sorry_details(sorry: Sorry):
    """Show detailed information about a specific sorry"""
    print(f"\n{'─'*80}")
    print(f"Sorry at {sorry.file}:{sorry.line}")
    if sorry.in_declaration:
        print(f"Declaration: {sorry.in_declaration}")
    print(f"{'─'*80}")

    if sorry.documentation:
        print("\nDocumentation:")
        for doc in sorry.documentation:
            print(f"  • {doc}")

    print("\nContext:")
    print("─" * 40)
    for line in sorry.context_before[-5:]:
        print(f"  {line}")
    print(f"  >>> SORRY HERE <<<")
    for line in sorry.context_after[:5]:
        print(f"  {line}")
    print("─" * 40)

    input("\nPress Enter to continue...")

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    # Catch common mistake: flag where target path is expected
    if sys.argv[1].startswith('-'):
        print("Error: missing target path (first argument must be a file or directory)", file=sys.stderr)
        print("Usage: sorry_analyzer.py <file-or-directory> [--format=FORMAT | --format FORMAT]", file=sys.stderr)
        sys.exit(1)

    target = Path(sys.argv[1])
    format_type = 'text'
    interactive = False
    include_deps = False
    exit_zero_on_findings = False

    # Parse arguments
    valid_formats = ('text', 'json', 'markdown', 'summary')
    format_aliases = {'detail': 'text'}
    i = 2
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg.startswith('--format='):
            format_type = arg.split('=', 1)[1]
            format_type = format_aliases.get(format_type, format_type)
            if format_type not in valid_formats:
                print(f"Error: Unknown format '{format_type}'. Valid: {', '.join(valid_formats)} (alias: detail -> text)", file=sys.stderr)
                sys.exit(1)
        elif arg == '--format':
            i += 1
            if i >= len(sys.argv):
                print("Error: --format requires a value", file=sys.stderr)
                sys.exit(1)
            format_type = sys.argv[i]
            format_type = format_aliases.get(format_type, format_type)
            if format_type not in valid_formats:
                print(f"Error: Unknown format '{format_type}'. Valid: {', '.join(valid_formats)} (alias: detail -> text)", file=sys.stderr)
                sys.exit(1)
        elif arg == '--interactive':
            interactive = True
        elif arg == '--include-deps':
            include_deps = True
        elif arg in ('--exit-zero-on-findings', '--report-only'):
            exit_zero_on_findings = True
        else:
            print(f"Error: Unknown flag: {arg}", file=sys.stderr)
            sys.exit(1)
        i += 1

    if not target.exists():
        print(f"Error: {target} does not exist", file=sys.stderr)
        sys.exit(1)

    # Find all sorries (excludes .lake/ by default)
    sorries = find_sorries(target, include_deps=include_deps)

    # Interactive mode takes precedence
    if interactive:
        interactive_mode(sorries)
        sys.exit(0 if len(sorries) == 0 or exit_zero_on_findings else 1)

    # Format output
    if format_type == 'json':
        print(format_json(sorries))
    elif format_type == 'markdown':
        print(format_markdown(sorries))
    elif format_type == 'summary':
        print(format_summary(sorries))
    else:
        print(format_text(sorries))

    # Exit code: 0 if no sorries, 1 if sorries found
    sys.exit(0 if len(sorries) == 0 or exit_zero_on_findings else 1)

if __name__ == '__main__':
    main()
